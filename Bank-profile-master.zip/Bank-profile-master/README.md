# Bank Profile

A new Flutter application.

I Will be Making Two UI designes of My own per Week :smile:
### Show some :heart: and :star: the repo to support the project and follow me

<img  height=500px width=300px src="https://github.com/BubblyBoy/Bank-profile/blob/master/Screenshot_20190525-164447.png"> 

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.io/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.io/docs/cookbook)

For help getting started with Flutter, view our 
[online documentation](https://flutter.io/docs), which offers tutorials, 
samples, guidance on mobile development, and a full API reference.
