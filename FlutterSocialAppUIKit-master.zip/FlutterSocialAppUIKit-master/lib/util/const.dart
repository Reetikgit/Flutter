class Constants {
  static String appName = 'Chat App';
}
