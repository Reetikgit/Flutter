class AppAnimations {
  static String chatAnimation = 'assets/animations/chat-anim.json';
}