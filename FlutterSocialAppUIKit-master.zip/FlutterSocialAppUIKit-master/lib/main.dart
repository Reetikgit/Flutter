import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'app.dart';

void main() async {
  runApp(MyApp());
}
