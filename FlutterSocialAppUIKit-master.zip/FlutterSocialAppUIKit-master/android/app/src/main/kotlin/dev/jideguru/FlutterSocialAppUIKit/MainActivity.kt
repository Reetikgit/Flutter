package dev.jideguru.FlutterSocialAppUIKit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
